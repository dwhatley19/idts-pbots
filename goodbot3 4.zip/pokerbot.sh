./player "$@"
